button text: Apps
primary color: 009999
gradient color: 009966
width (pixels): 52
height (pixels): 24
corner radius (pixels): 6
text height (points): 12
text color: ffffff
background color: clear
font name: HelvBoldOblique
rollover primary color: 009966
rollover gradient color: 009999
rollover text color: ffffff
quality: 3
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/glassy.php?button_text=Apps&amp;color=009999&amp;grcolor=009966&amp;width=52&amp;height=24&amp;radius=6&amp;theight=12&amp;tcolor=ffffff&amp;bkcolor=clear&amp;fname=HelvBoldOblique&amp;rcolor=009966&amp;rgrcolor=009999&amp;rtcolor=ffffff&amp;imglocate=none&amp;imgheight=12&amp;imgname=&amp;imgfore=auto&amp;imgforecolor=000000&amp;imgtran=auto&amp;imgtrancolor=ffffff&amp;quality=3&amp;fromhere=1
